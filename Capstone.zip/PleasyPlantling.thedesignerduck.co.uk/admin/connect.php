<?php
// connecting to DB 
    $connect = mysqli_connect("localhost", "PleasyPAdmin", "Chr1stopher!2021", "ThePleasyPlantling_db");
// error message 
    if(!$connect){
        echo "<h3>Not able to establish Database Connection</h3>";
    }
    
    //$SQL = "SELECT * FROM Reviews"
   // loop though reviews
   // if rating = 1
   // so on 
   // one ++
   
    $rating_display = mysqli_query($connect,"SELECT * FROM Reviews");
    
         //--------------- Admin Login -----------------//
         // sets off when people click login
    if(!empty($_POST['Login'])){
        // requesting data from form
        $Username = $_POST['UserName'];
        $Password = $_POST['Password'];
        
        // SQL query to execute 
        $SQL = "SELECT * FROM Admin WHERE UserName = '$Username' AND Password = '$Password'";
        $query = mysqli_query($connect,$SQL);
        $sucess = mysqli_num_rows($query);
        // if logged in redirected to admin board
        if($sucess>0){
            echo "login sucessful";
            header("Location: dashboard.php");
        }
        else{
            echo "login failed";
            header("Location: login.php");
        }
    }
     //--------------- Admin Change Username -----------------//
         // sets off when people click login
    if(!empty($_POST['ChangeUserName'])){
        // requesting data from form
        $Username = $_POST['UserName'];
        $NewUsername = $_POST['NewUserName'];
        $Password = $_POST['Password'];
        
         
        if( $Username !== $NewUsername){
            // if it worked checking if the username and password is correct 
        $SQL = "SELECT * FROM Admin WHERE UserName = '$Username' AND Password = '$Password'";
        $query = mysqli_query($connect,$SQL);
        $sucess = mysqli_num_rows($query);
        //  checking if the row was returned for them 
        if ($sucess>0) {
            // SQL query to execute 
            $SQL = "UPDATE Admin SET UserName = '$NewUsername' WHERE UserName = '$Username' AND Password = '$Password'";
        
            $query = mysqli_query($connect,$SQL);
            header("Location: dashboard.php");
            exit();
        } else {
            // sending a message if it was not 
            $error='Password or Username not found';
             header('Location: change_username.php?UNerror='.$UNerror);
        }
        }else{
             $UNerror='Usernames are the same. Please choose a new username!';
             header('Location: change_username.php?UNerror='.$UNerror);
        }
        
    }
    //--------------- Admin Change Password -----------------//
         // sets off when people click login
    if(!empty($_POST['ChangePassword'])){
        // requesting data from form
        $Username = $_POST['UserName'];
        $Password = $_POST['Password'];
        $NewPassword = $_POST['NewPassword'];
        $NewPassword2 = $_POST['NewPassword2'];
        
       // double check if the password is the same again
        if($NewPassword!== $NewPassword2) {
             header("location: change_password.php");
             // adding in a message for the admin
             $error='Passwords do not match';
             //sending the message though the header
             header('Location: change_password.php?error='.$error);
        } else {
            // if it worked checking if the username and password is correct 
        $SQL = "SELECT * FROM Admin WHERE UserName = '$Username' AND Password = '$Password'";
        $query = mysqli_query($connect,$SQL);
        $sucess = mysqli_num_rows($query);
        //  checking if the row was returned for them 
        if ($sucess>0) {
            // SQL query to execute if the username and password was correct
        $SQL = "UPDATE Admin SET Password = '$NewPassword' WHERE UserName = '$Username' AND Password = '$Password'";
            $query = mysqli_query($connect,$SQL);
             header("Location: dashboard.php");
            exit();
        } else {
            // sending a message if it was not 
            $error='Password or Username not found';
             header('Location: change_password.php?error='.$error);
        }
        
        
        
        }
        
    }
    
      //--------------- Getting all Recipes to display -----------------//
        $SQL = "SELECT * FROM Recipes"; // selecting everything from recipes
        $Display = mysqli_query($connect, $SQL);// running the query
        
        // if header contains id
        if(isset($_REQUEST['ID'])){
            $ID = $_REQUEST['ID'];
            
            
            $SQL= "SELECT * FROM Recipes WHERE ID = $ID";
            $Display = mysqli_query($connect,$SQL);
            
        }

    //------------- Creating a Recipe ----------------------------//
        if(isset($_REQUEST['NewRecipe'])){// sets off when button is clicked 
            $Name = $_REQUEST['Name'];// requesting all input from forms
            $total_Time = $_REQUEST['total_time'];
            $prep_time = $_REQUEST['prep_time'];
            $cook_time = $_REQUEST['cook_time'];
            $CoverImage = $_REQUEST['CoverImage'];
            $Date = $_REQUEST['Date'];
            $Description = $_REQUEST['Description'];
            $Type = $_REQUEST['Type'];
            $Tags= $_REQUEST['Tags'];
            $Ingredients = $_REQUEST['Ingredients'];
            $Directions = $_REQUEST['Directions'];
            $Notes = $_REQUEST['Notes'];
            
            //Special as alergens are a check box 
            $Allergens = $_REQUEST['Allergens'];
            // new location as a string
            $Allergen="";
            // looping though allergens and adding them to new location
            foreach($Allergens as $A){  
                $Allergen .= $A.",";  
            } 
            // SQL statement to insert new data 
            $SQL= "INSERT INTO Recipes(Name, Total_Time, Cook_Time, Prep_Time, CoverImage, Description, Allergens, Ingredients, Directions, Notes, Type, Tags, Date)
            VALUES('$Name', '$total_Time','$cook_time','$prep_time', '$CoverImage', '$Description', '$Allergen', '$Ingredients', '$Directions',  '$Notes', '$Type', '$Tags', '$Date')";
            mysqli_query($connect, $SQL);
            // sucess message and takes you back to dashboard
            header("Location: dashboard.php?Recipe=added?");
            exit();
        }
        // Edit a post
    if(isset($_REQUEST['Save'])){
        $id = $_REQUEST['id'];
        $name = $_REQUEST['Name'];
        $time = $_REQUEST['Time'];
        $description = $_REQUEST['Description'];
        $ingredients = $_REQUEST['Ingredients'];
        $directions = $_REQUEST['Directions'];
        $type = $_REQUEST['Type'];
        $tags = $_REQUEST['Tags'];
        $notes = $_REQUEST['Notes'];

        $SQL = "UPDATE Recipes SET Name = '$name', Total_Time = '$time',Description = '$description', Ingredients = '$ingredients', Directions = '$directions', Type = '$type', Notes = '$notes' WHERE id = $id";
        mysqli_query($connect, $SQL);

        header("Location: recipes.php");
        exit();
    }
        // Delete a post
    if(isset($_REQUEST['delete'])){
        $id = $_REQUEST['id'];

        $SQL = "DELETE FROM Recipes WHERE ID = $id";
        mysqli_query($connect, $SQL);

        header("Location: recipes.php");
        exit();
    }
 
?>