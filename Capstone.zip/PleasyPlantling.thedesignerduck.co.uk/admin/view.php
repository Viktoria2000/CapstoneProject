<?php
    include "connect.php";
    include "admin_menu.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!--- Font Import -->
        <link href="https://fonts.googleapis.com/css2?family=Neucha&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
     body{
        font-family: 'Neucha', cursive;

    }
    form{
        display:inline-block;
        float: right;
    }
     .button{
        /*Decorating the text*/
        font-family: 'Neucha', cursive;
        font-size: 17px;
        text-decoration:none;
        color:#FFFFFF;
        text-align:center;
        
        /*styling the button*/
        display:inline-block;
        padding: 10px 25px 10px 25px;
        margin:0 5px 5px 0;
        border-radius:15px;
        box-sizing: border-box;
        background-color:#11243a;
        
        /*controlling colour change*/
        transition: all 0.4s;
    }
    .button:hover{
        background-color:#b98a54;
        cursor: pointer;
        
    }

    .content{
        background-color: white;
        position: absolute;
        text-align:left;
        padding: 3%;
        margin-top: 1%;
        padding-right:15%;
        

    }

    
        
}

        
    </style>
</head>
<body>
    <div class="main">
    <div class="all">
        
       
        <?php foreach($Display as $recipes){ ?>
        
     
        <div class="content">
            <form method="POST">
                    <input type="text" hidden value='<?php echo $recipes['ID']?>' name="id">
                    <button class="button" name="delete">Delete  <i class='bx bxs-trash'></i></button>
            </form>
            <form method="POST">
                <button class="button" formaction="edit.php?ID=<?php echo $recipes['ID']?>">Edit  <i class='bx bxs-edit' ></i></button>
            </form><br>
            <h1><?php echo $recipes['Name'];?></h1>
            <h4><i class='bx bx-timer'></i> <?php echo $recipes['Total_Time'];?> Minutes</h4>
        <div>
            <h3> Description</h3>
            <p><?php echo $recipes['Description'];?></p>
        </div>
        <div>
            <h3> Allergens </h3>
            <p><?php echo $recipes['Allergens'];?></p>
        </div>
        <div>
            <h3> Ingredients</h3>
            <p><?php echo $recipes['Ingredients'];?></p>
        </div>
        <div >
            <h3>Directions</h3>
            <p><?php echo $recipes['Directions'];?></p>
        </div>
        <div>
            <h3>Type</h3>
            <p><?php echo $recipes['Type'];?></p>
        </div>
        <div>
            <h3>Tags</h3>
            <p><?php echo $recipes['Tags'];?></p>
        </div>
        <div>
            <h3>Notes</h3>
            <p><?php echo $recipes['Notes'];?></p>
        </div>
        <div>
            <h3>Date</h3>
            <p><?php echo $recipes['Date'];?></p>
        </div>
            <?php }?>                    
        </div>
    </form>
</div>
   </div>
   </div>
   </div>



</body>
</html>