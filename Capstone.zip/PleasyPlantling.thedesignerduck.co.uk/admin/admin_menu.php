<!DOCTYPE html>
<html>
<head>
    <title> Admin Page </title>
        <!-- CSS -->
        <link rel="stylesheet" href="./CSS/Admin.css">
        <link rel="shortcut icon" href="/images/logo_small.png" type="image/png">
        <!--- Font Import -->
        <link href="https://fonts.googleapis.com/css2?family=Neucha&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
        <!-- Boxonics -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

<div class="Options">
    <div class="SideMenu-User-Info">
                    <div class="UserName">
                        <h4 id="Name">Pleasy Plantling</h4>
                    </div>
                </div>
  <a href="https://pleasyplantling.thedesignerduck.co.uk/admin/dashboard.php" id="Link"><i class='bx bxs-home' ></i>  Dashboard</i></a>
  <a href="https://analytics.google.com/analytics/web/#/p291064748/reports/reportinghub" id="Link"><i class='bx bx-bar-chart-square' ></i>  Google Analytics </i></a>
  <button class="Button" id="Link"> <i class='bx bxs-food-menu'></i>  Recipes
    <i class='bx bxs-chevrons-down' ></i>
  </button>
  <div class="Container">
    <a href="https://pleasyplantling.thedesignerduck.co.uk/admin/recipes.php" id="Link"><i class='bx bxs-archive' ></i>  View Posts</a>
    <a href="https://pleasyplantling.thedesignerduck.co.uk/admin/create.php"  id="Link"><i class='bx bxs-add-to-queue' ></i>  Post Recipe</a>
  </div>
  <button class="Button" id="Link"><i class='bx bxs-cog' ></i>  Settings</span>
    <i class='bx bxs-chevrons-down' ></i>
  </button>
  <div class="Container">
    <a href="https://pleasyplantling.thedesignerduck.co.uk/admin/change_username.php" id="Link"><i class='bx bxs-user-detail' ></i>  Change Username</a>
    <a href="https://pleasyplantling.thedesignerduck.co.uk/admin/change_password.php" id="Link"><i class='bx bxs-key'></i>  Change Password</a>
  </div>
</div>



<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var Content = document.getElementsByClassName("Button");
var i;

for (i = 0; i < Content.length; i++) {
  Content[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</body>
</html> 