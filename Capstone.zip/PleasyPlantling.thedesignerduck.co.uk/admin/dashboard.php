<!DOCTYPE html>
<html>
<?php
    include "admin_menu.php";
    include "connect.php";
?>
<script
src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
</script>
<style>

    .t{
        display: inline-block;
    }
    .review_visualization{
        width: 60%;
    }
    .b{
         background-color: #DCDCDC;
       margin: 5%;
       padding: 1% 10% 15% 10%;
       font-size: 18px;
       border-radius: 10px;
       width: 300px;
       height: 70px;
       text-align: center;
    }


   body{
        font-family: 'Neucha', cursive;
   }
   .recent_review{
       background-color: #DCDCDC;
       margin: 2%;
       padding: 2%;
       font-size: 18px;
       border-radius: 10px;
       
   }
   
</style>
<?php 

       
      $rating_display = mysqli_query($connect,"SELECT * FROM Reviews");
      $number_of_reviews = mysqli_num_rows($rating_display);
        
      $total = 0; 
      $one = 0;
      $two = 0;
      $three = 0;
      $four = 0;
      $five = 0;
      
      $one_tracker = 0;
      $two_tracker = 0;
      $three_tracker = 0;
      $four_tracker = 0;
      $five_tracker = 0;
      
      
      foreach($rating_display as $r){
        $rating = $r['stars'];
        $total = $total + $rating;
        
        switch ($rating) {
          case 1:
            $one = $one + $rating;
            $one_tracker++;
            break;
          case 2:
            $two = $two + $rating;
            $two_tracker++;
            break;
          case 3:
            $three = $three + $rating;
            $three_tracker++;
            break;
          case 4:
            $four = $four + $rating;
            $four_tracker++;
            break;
          case 5:
            $five = $five + $rating;
            $five_tracker++;
            break;
        }
      }
      $average = ($one * 1 + $two * 2 + $three * 3 + $four * 4 + $five * 5 )/$total;
      
      $recent_reviews = mysqli_query($connect,"SELECT * FROM Reviews ORDER BY date DESC");
      
      $saves = mysqli_query($connect,"SELECT * FROM Bookmarks");
      $users = mysqli_query($connect,"SELECT * FROM Users");
      
      $total_saves = mysqli_num_rows($saves);
      $total_users = mysqli_num_rows($users);
      
      
      
?>    

<body>
    <div class="main">
        <div class="top">
            <div class="review_visualization t">
                <h3>Rating Breakdown:</h3>
                <canvas id="myChart" style="width:100%;max-width:1000px"></canvas>
                <center><h4>Overall Ratings: <?php echo number_format($average, 1);?></h4></center>
            </div>
        <div class="engagement t">
             <h3>Engagement:</h3>
            <div class="total_reveiews b">
                <h4>Reviews:</h4>
                <p><b><?php echo $number_of_reviews;?></b></p>
            </div>
            <div class="total_saves b">
                <h4>Favourited:</h4>
                <p><b><?php echo $total_saves;?></b></p>
            </div>
            <div class="total_members b">
                <h4> Members:</h4>
                <p><b><?php echo $total_users;?></b></p>
            </div>
        </div>
         <div class="bottom">
            <h3>New Reviews:</h3>
            <?php 
            $three_new = 0;
              foreach($recent_reviews as $recent){
                  ?>
                  <div class="recent_review">
                  <?php
                $date = $recent['date'];
                $comments= $recent['comments'];
                $rating = $recent['stars'];
                $id = $recent['recipe_id'];
                ?> 
                <h4>Rating:   <?php echo $rating ?> for recipe: <?php echo $id?></h4>
                <p><?php echo  $comments?> </p>
                <p><?php echo  $date?> </p>
                <?php
                $three_new ++;
                if($three_new == 3){
                    break;
                }
                  ?></div><?php
                  
              }
          ?>
            </div>
        </div>
        
    </div>

<script>

var xValues = ["1★", "2★", "3★","4★","5★"];
var one = '<?php echo $one_tracker;?>';
var two = '<?php echo $two_tracker;?>';
var three = '<?php echo $three_tracker;?>';
var four = '<?php echo $four_tracker;?>';
var five = '<?php echo $five_tracker;?>';

var yValues = [one, two, three, four, five];
var barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145"
];

new Chart("myChart", {
  type: "doughnut",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  }
});
</script>

    
    
</body>

</html>