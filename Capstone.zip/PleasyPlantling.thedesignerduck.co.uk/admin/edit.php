<?php
    include "connect.php";
    include "admin_menu.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!--- Font Import -->
        <link href="https://fonts.googleapis.com/css2?family=Neucha&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
    img{
        width:70%;
    }
    body{
        font-family: 'Neucha', cursive;
    }
    .Title{
        display: inline;
    }
    textarea{
        width: 50%;
        text-align:center;
    }
    .button{
        /*Decorating the text*/
        font-family: 'Neucha', cursive;
        font-size: 17px;
        text-decoration:none;
        color:#FFFFFF;
        text-align:center;
        
        /*styling the button*/
        display:inline-block;
        padding: 10px 25px 10px 25px;
        margin:0 5px 5px 0;
        border-radius:15px;
        box-sizing: border-box;
        background-color:#11243a;
        
        /*controlling colour change*/
        transition: all 0.4s;
        float:right;
    }
    .button:hover{
        background-color:#b98a54;
        cursor: pointer;
        
    }

    .content{
        background-color: white;
        margin-top: 1%;
        position: absolute;
        text-align:left;
        align-items:center;
        border-radius: 15px;
        padding: 3%;
         background-attachment: fixed;
         position: relative;

    }

    </style>
</head>
<body>
   
   <div class="main">
       <div class="all">
       <?php foreach($Display as $recipes){ ?>
        <div class="content">
       <form method="POST">
                <button class="button" name="Save">Save  <i class='bx bx-save'></i></i></button><br>
                <br>
                <input type="text" hidden value='<?php echo $recipes['ID']?>' name="id">
            <h3> Title:</h3>
                <input type="text" name="Name" value="<?php echo $recipes['Name']?>">
            <h3> Time (Minutes):</h3>
            <input type="text" name="Time" value="<?php echo $recipes['Total_Time'];?>"</input>
      
            <h3> Description:</h3>
            <textarea name="Description" cols="30" rows="10"><?php echo $recipes['Description']?></textarea>
            <h3> Ingredients:</h3>
            <textarea name="Ingredients" cols="30" rows="10"><?php echo $recipes['Ingredients'];?></textarea>
            <h3>Directions:</h3>
            <textarea name="Directions" cols="30" rows="10"><?php echo $recipes['Directions'];?></textarea>

            <h3>Type:</h3>
            <input type="text" name="Type" value="<?php echo $recipes['Type'];?>">
            <h3>Tags:</h3>
            <input type="text" name="Tags" value="<?php echo $recipes['Tags'];?>">
            <h3>Notes:</h3>
            <textarea type="text" name="Notes" value="<?php echo $recipes['Notes'];?>"></textarea>
            <h3>Date:</h3>
            <p><?php echo $recipes['Date'];?></p>
            <?php }?>                    

    </form>
    </div>
    </div>
</div>
   </div>



</body>
</html>