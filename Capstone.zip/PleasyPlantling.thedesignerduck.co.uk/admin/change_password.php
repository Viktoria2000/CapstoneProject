<?php 
    include "connect.php";
    include "admin_menu.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Admin Login</title>
        <!--- Font Import -->
        <link href="https://fonts.googleapis.com/css2?family=Neucha&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
		<!-- Boxonics -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <style>
            body{
                background-color: white;
            }
            .login{
                background-color: white;
                width: 50%;
                text-align: center;
                padding: 3%;
                margin: 3% auto;
                
            }
            .bxs-user .bxs-lock-alt{
                font-size: 30px;
                color: #11243a;
            
            }
            input{
                padding: 8px;
                margin-bottom: 2%;
                border-radius: 10px;
                width: 50%;
                font-family: 'Neucha', cursive;
                font-size: 17px;
                text-align: center;
                letter-spacing: 1px;
            }
            h1{
                font-family: 'Neucha', cursive;
                padding: 1%;
                color: #11243a;
                letter-spacing: 2px;
            }
            hr.divider{
                border-top: 3px solid #11243a;;
                margin-bottom: 30px;
                max-width: 30%;
            }   
            .Submit{
                background-color: #11243a;;
                color: white;
                border:none;
            
            }
            

            
        </style>
	</head>
	<body>
	    <script>
				var check = function() {
				    var error = document.getElementById("error");
				    if(document.getElementById("NP").value == document.getElementById("NP2").value){
				        error.style.color = 'green';
                        error.innerHTML = "<p> <i class='bx bx-check'>Passwords are a match!</i></p>";
                     }else {
                        error.style.color = 'red';
                        error.innerHTML = "<p> <i class='bx bx-x'></i> Passwords are Different! Please try again!</p>";
                        }
                }
				</script>
		<div class="login">
			<h1>Change Password</h1>
            <hr class="divider">
			<form action="change_password.php" method="POST">
			    <?php if(isset($_GET['error']) && $_GET['error']!="") { ?>
                    <p name="message"><?php echo $_GET['error']; ?> </p>
                <?php } ?>
			     <div class="icon">
					<i class='bx bxs-user' style="font-size: 30px; color: #11243a;" ></i>
				</div>
				<input type="text" name="UserName"  id="username" placeholder="Username" required/><br>
				<div class="icon">
					<i class='bx bxs-lock-alt' style="font-size: 30px; color: #11243a;"></i>
                </div>
				<input type="password" name="Password" id="password" placeholder="Password"  required/><br>
				<input type="password" name="NewPassword" id="NP" placeholder="New Password" onkeyup='check();' required/><br>
				<input type="password" name="NewPassword2" id="NP2" placeholder="Confirm New Password" onkeyup='check();' required/><br>
					<p id="error"></p>
				<input class="Submit" type="submit" name="ChangePassword"/>
			</form>
		</div>
	</body>
</html>