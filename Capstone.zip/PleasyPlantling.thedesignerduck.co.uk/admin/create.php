<?php
    include "connect.php";
    include "admin_menu.php"
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<style>
   .field{
        width: 50%;
        padding: 1%;
        border-radius: 20px;
    }
</style>
<body>
    <div class = "main">
    <form method="POST" enctype="multipart/form-data">
        <h4>Recipe Name:</h4>
        <input class="field" name="Name" type="text" placeholder="Recipe Name">
        <h4>Time to Create:</h4>
        <input class="field" name="total_time" type="number" placeholder="45 Mins">
        <h4>Prep Time:</h4>
        <input class="field" name="prep_time" type="number" placeholder="15 Mins">
        <h4>Cook Time:</h4>
        <input class="field" name="cook_time" type="number" placeholder="30 Mins">
        <h4>Cover Image Google Link:</h4>
        <input class="field" type="text" name="CoverImage" >
        <h4>Date:</h4>
        <input name="Date" type="date">
        <h4>Description:</h4>
        <textarea  class="field"name="Description" cols="30" rows="10"></textarea>
        <h4>Allergens:</h4>
        <input type="checkbox" name="Allergens[]" value="Soy">Soy<br>
        <input type="checkbox" name="Allergens[]" value="Peanut">Peanut<br>
        <input type="checkbox" name="Allergens[]" value="Tree Nut">Tree Nut<br>
        <input type="checkbox" name="Allergens[]" value="Sesame">Sesame <br>
        <input type="checkbox" name="Allergens[]" value="Gluten">Gluten <br>
        <input type="checkbox" name="Allergens[]" value="None">None<br>
        <h4>Type:</h4>
        <input class="field"name="Type" type="text" placeholder="Breakfast?">
        <h4>Tags:</h4>
        <input  class="field"name="Tags" type="text" placeholder="Savory?">
        <h4>Ingredients: </h4>
        <textarea class="field" name="Ingredients" cols="30" rows="10"></textarea>
        <h4>Directions: </h4>
        <textarea  class="field"name="Directions" cols="30" rows="10"></textarea>
        <h4>Notes: </h4>
        <textarea class="field" name="Notes" cols="30" rows="10"></textarea>
        <button name="NewRecipe">Create Recipe</button>
    </form>
    </div>
</body>
</html>