<?php
    include "connect.php";
    include "admin_menu.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
    .container {
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  width:100%;
  justify-content: center;
}
        .recipe{
            background-color: #b98a54;
            font-family: 'Neucha', cursive;
            color: #11243a;
            width: 25%;
            border-radius: 15px;
            text-align: center;
            display: flow-root;
            margin: 10px;
            
            
            
        }
        .recipe a{
            text-decoration: none;
            color: #11243a;
        }
        
        img{
            max-width: 100%;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        
    </style>
</head>
<body>

   <div class="main">
       <div class="container">
        <?php foreach($Display as $recipes){ ?>
        <div class="recipe">
                            <?php echo $recipes['CoverImage'];?>
                            <a href="view.php?ID=<?php echo $recipes['ID']?>"><h5 ><?php echo $recipes['Name'];?></h5></a>
                            </div>
            <?php }?>                    

        </div>
    
    </div>
    </div>
   </div>



</body>
</html>