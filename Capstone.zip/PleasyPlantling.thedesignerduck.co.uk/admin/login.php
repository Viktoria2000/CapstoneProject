
<?php 
    include "connect.php"
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Admin Login</title>
        <!--- Font Import -->
        <link href="https://fonts.googleapis.com/css2?family=Neucha&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
		<!-- Boxonics -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <style>
            body{
                background-color: #11243a;
            }
            .login{
                background-color: white;
                width: 30%;
                text-align: center;
                padding: 35px;
                margin: 10% auto;
                border-radius: 20px;
            }
            .bx{
                font-size: 30px;
                color: #11243a;
            
            }
            input{
                padding: 8px;
                margin-bottom: 2%;
                border-radius: 10px;
                width: 50%;
                font-family: 'Neucha', cursive;
                font-size: 17px;
                text-align: center;
                letter-spacing: 1px;
            }
            h1{
                font-family: 'Neucha', cursive;
                padding: 1%;
                color: #11243a;
                letter-spacing: 2px;
            }
            hr.divider{
                border-top: 3px solid #b98a54;
                margin-bottom: 30px;
                max-width: 30%;
            }   
            .Submit{
                background-color: #b98a54;
                color: #11243a;
            }

            
        </style>
	</head>
	<body>
		<div class="login">
			<h1>Login</h1>
            <hr class="divider">
			<form action="login.php" method="POST">
                <div class="icon">
					<i class='bx bxs-user' ></i>
				</div>
				<input type="text" name="UserName"  id="username" placeholder="Username" required/><br>
				<div class="icon">
					<i class='bx bxs-lock-alt' ></i>
                </div>
				<input type="password" name="Password" id="password" placeholder="Password"  required/><br>
				<input class="Submit" value="Login" type="submit" name="Login"/>
			</form>
		</div>
	</body>
</html>