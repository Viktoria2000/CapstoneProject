<?php 
    include "connect.php";
    include "admin_menu.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Admin Login</title>
        <!--- Font Import -->
        <link href="https://fonts.googleapis.com/css2?family=Neucha&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
		<!-- Boxonics -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <style>
            body{
                background-color: white;
            }
            .login{
                background-color: white;
                width: 50%;
                text-align: center;
                padding: 3%;
                margin: 4% auto;
                
            }
            .bxs-user .bxs-lock-alt{
                font-size: 30px;
                color: #11243a;
            
            }
            input{
                padding: 8px;
                margin-bottom: 2%;
                border-radius: 10px;
                width: 50%;
                font-family: 'Neucha', cursive;
                font-size: 17px;
                text-align: center;
                letter-spacing: 1px;
            }
            h1{
                font-family: 'Neucha', cursive;
                padding: 1%;
                color: #11243a;
                letter-spacing: 2px;
            }
            hr.divider{
                border-top: 3px solid #11243a;;
                margin-bottom: 30px;
                max-width: 30%;
            }   
            .Submit{
                background-color: #11243a;;
                color: white;
                border:none;
            
            }

            
        </style>
	</head>
	<body>
		<div class="login">
			<h1>Change Username</h1>
            <hr class="divider">
            <?php if(isset($_GET['UNerror']) && $_GET['UNerror']!="") { ?>
                    <p name="message"><?php echo $_GET['UNerror']; ?> </p>
            <?php } ?>
			<form action="change_username.php" method="POST">
                <div class="icon">
					<i class='bx bxs-user' style="font-size: 30px; color: #11243a;" ></i>
				</div>
				<input type="text" name="UserName"  id="username" placeholder="Username" required/><br>
				<input type="text" name="NewUserName"  id="username" placeholder="New Username" required/><br>
				<div class="icon">
					<i class='bx bxs-lock-alt' style="font-size: 30px; color: #11243a;"></i>
                </div>
				<input type="password" name="Password" id="password" placeholder="Password"  required/><br>
            
				<input class="Submit" type="submit" name="ChangeUserName"/>
			</form>
		</div>
	</body>
</html>